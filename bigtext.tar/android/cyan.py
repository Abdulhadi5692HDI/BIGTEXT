from colorama import Fore,Back
print(Fore.CYAN + "\c")

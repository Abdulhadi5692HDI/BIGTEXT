from colorama import Fore
print(Fore.RED + "")

sh modules/Example/bin/mod.sh
		
#cyan="python  /data/data/com.termux/files/usr/share/cyan.py"
#$cyan
#echo "
 #________  ___  ________ _________  _______      ___    ___ _________   
#|\   __  \|\  \|\   ____\\___   ___\\  ___ \    |\  \  /  /|\___   ___\ 
#\ \  \|\ /\ \  \ \  \___\|___ \  \_\ \   __/|   \ \  \/  / ||___ \  \_| 
# \ \   __  \ \  \ \  \  ___  \ \  \ \ \  \_|/__  \ \    / /     \ \  \  
#  \ \  \|\  \ \  \ \  \|\  \  \ \  \ \ \  \_|\ \  /     \/       \ \  \ 
 #  \ \_______\ \__\ \_______\  \ \__\ \ \_______\/  /\   \        \ \__\
 #   \|_______|\|__|\|_______|   \|__|  \|_______/__/ /\ __\        \|__|
                                                |__|/ \|__|             
   
#"  lolcat

#echo -e
#sleep 3
#python red.py
#echo ""
#echo "Installing Packages"
#pip install colorama
#apt install figlet


#echo "I| Now type text and press enter to get big ascii version" | lolcat
#python /data/data/com.termux/files/usr/share/red.py
#echo "Notice| You have 10 tries"
#$cyan
#echo "text>>"
#read text
#figlet $text
#read text
#figlet $text
#read text
#figlet $text
#read text
#figlet $text
#read text


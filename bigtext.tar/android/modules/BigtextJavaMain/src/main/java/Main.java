public class Main {
	public static void main(String[] args) {
		System.out.println("Please do not run the jar , BT will run it");
	}
}

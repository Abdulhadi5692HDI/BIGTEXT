# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.3.x  | :x:                |
| ZIP Download | :white_check_mark: |
| APT Download  | :x:                |

## Notes

The APT Download is actually outdated and the ZIP is always okay to use

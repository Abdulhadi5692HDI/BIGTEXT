# Bigtext
## Info
[![BigText Build](https://github.com/Abdulhadi5692HDI/BIGTEXT/actions/workflows/main.yml/badge.svg)](https://github.com/Abdulhadi5692HDI/BIGTEXT/actions/workflows/main.yml)
> Announcement 15/11/21

This project will be not work on because im very busy


------------- End of Announce ---------


Such BIGTeXT in ASCII can be made with this small tool!

> OS Surported: Android (via termux (APT must be enabled))

> There will be nor or either be surport for Windows

For Help and Examples: See the <a href="https://github.com/Abdulhadi5692HDI/BIGTEXT/wiki">WIKi</a>

BigText 0.2 Post: 

Also for a another cleaner version go into github-pages

!! NEED PYTHON !!

> APT Install (unstable)
```apt install ./bigtext_2_all.deb```
Note: Colors will not work and python will display errors

>Then:
```bigtext```
without ./ or /

>Also can do:
```~/../usr/bigtext```
>Because of update little bit of errors are going to DISPLAY

You can also download the latest dev build: <a href="https://github.com/Abdulhadi5692HDI/BIGTEXT/raw/main/bigtext.tar"><img src="https://abdulhadishahzad.xp3.biz/zip.png"/>bigtext.tar</a>
Info of the zip image is here: <a href="https://abdulhadishahzad.xp3.biz/zip-info.html">zip-info.html</a>
